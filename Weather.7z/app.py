from flask import Flask, jsonify, request
import os
import time
from urllib.request import urlopen
from datetime import datetime, timedelta
import re  # 정규 표현식 사용을 위한 import
import requests
import struct
from flask_cors import CORS  # CORS 모듈 추가

app = Flask(__name__)
CORS(app)  # CORS 설정 추가

# API 관련 설정
domain = "https://apihub.kma.go.kr/api/typ01/url/kma_sfctm5.php?"
obs = "obs=TA&"
tm2 = "tm2=" + datetime.now().strftime("%Y%m%d%H%M") + "&"
stn_id = "stn=108&"
option = "disp=0&help=0&"
auth = "authKey=mUwDsefKRcSMA7HnysXE6g"

domain2 = "https://apihub.kma.go.kr/api/typ01/url/fct_afs_dl.php?"
reg = "reg=11B10101&"
disp2 = "disp=0&"
help2 = "help=0&"



# 발표 시각 계산
today = datetime.now()
current_hour = today.hour
if current_hour < 6:
    base_time = today.replace(hour=18, minute=0, second=0, microsecond=0) - timedelta(days=1)
elif current_hour < 18:
    base_time = today.replace(hour=6, minute=0, second=0, microsecond=0)
else:
    base_time = today.replace(hour=18, minute=0, second=0, microsecond=0)

tmfc1 = f"tmfc1={(base_time - timedelta(hours=12)).strftime('%Y%m%d%H')}&"
tmfc2 = f"tmfc2={base_time.strftime('%Y%m%d%H')}&"

# 함수 정의
def get_today_weather():
    try:
        directory = "today_weather"
        file_name = os.path.join(directory, "today_weather_sync.csv")
        if not os.path.exists(directory):
            os.makedirs(directory)
        
        if os.path.exists(file_name):
            file_time = datetime.fromtimestamp(os.path.getmtime(file_name))
            if file_time.strftime("%Y%m%d%H") == datetime.now().strftime("%Y%m%d%H"):
                return file_name, None
        
        with urlopen(domain + obs + stn_id + option + auth) as f:
            binary_data = f.read()
        text_data = binary_data.decode('euc-kr')
        with open(file_name, "w", encoding="utf-8") as f:
            f.write(text_data)
        return file_name, None
    except Exception as e:
        return str(e), None

def extract_temperature(file_name):
    try:
        with open(file_name, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.startswith('2024'):  # 날짜로 시작하는 유효 데이터 줄
                    parts = line.split()
                    date = parts[0]
                    val = parts[-1]
                    return date, float(val)
    except Exception as e:
        return None, None
    
    
def extract_avg_temperature(data):
    """
    Extracts the average temperature from the data by parsing through the CSV content.
    """
    # Clean the data by removing markers
    clean_data = re.sub(r'#START7777|#7777END', '', data, flags=re.DOTALL)
    lines = clean_data.strip().splitlines()
    temperatures = []

    for line in lines:
        if line.startswith('#') or not line.strip():  # Skip comments or empty lines
            continue
        columns = line.split(',')
        if len(columns) > 10:  # Ensure sufficient columns exist
            try:
                avg_temperature = float(columns[10])
                temperatures.append(avg_temperature)
            except ValueError:
                continue  # Skip rows with invalid temperature data

    return {"temperatures": temperatures}

def calculate_daily_avg_temperature(input_date_str):
    """
    Fetches the data for the selected date and calculates the average temperature.
    :param input_date_str: Date in the format YYYYMMDD
    """
    try:
        # Validate and convert input date
        input_date = datetime.strptime(input_date_str, '%Y%m%d')
        tm = input_date.strftime('%Y%m%d')

        # URL to fetch data
        url = f"https://apihub.kma.go.kr/api/typ01/url/kma_sfcdd.php?tm={tm}&stn=108&help=0&authKey=mUwDsefKRcSMA7HnysXE6g"
        response = requests.get(url)

        if response.status_code != 200:
            return {"error": f"Failed to fetch data. HTTP Status: {response.status_code}"}

        data = response.text
        extracted_data = extract_avg_temperature(data)
        temperatures = extracted_data["temperatures"]

        if not temperatures:
            return {"error": "No temperature data found."}
        
        # 평균 계산
        avg_temperature = sum(temperatures) / len(temperatures) 

        return {
            "date": tm,
            "average_temperature": round(avg_temperature, 2),
            "data_source": url
        }

    except ValueError:
        return {"error": "Invalid date format. Please use YYYYMMDD."}
    except Exception as e:
        return {"error": str(e)}

def get_forecast_weather():
    try:
        directory = "forecast_3_weather"
        file_name = os.path.join(directory, "forecast_data.csv")
        if not os.path.exists(directory):
            os.makedirs(directory)
        with urlopen(domain2 + reg + tmfc1 + tmfc2 + disp2 + help2 + auth) as f:
            binary_data = f.read()
        text_data = binary_data.decode('euc-kr')
        with open(file_name, 'w', encoding='utf-8') as file:
            file.write(text_data)
        return file_name, None
    except Exception as e:
        return str(e), None

def extract_forecast_data_with_period(file_name):
    try:
        with open(file_name, "r", encoding="utf-8") as f:
            lines = f.readlines()
            result = []
            for line in lines:
                if line.startswith("#") or line.strip() == "":
                    continue
                parts = line.split()
                if len(parts) >= 16:
                    try:
                        TM_EF = parts[2]
                        TA = parts[12]
                        ST = parts[13]
                        WF = parts[16].strip('"')
                        if TA == "-99":
                            result.append({"time": TM_EF, "temperature": "No data", "강수확률": ST, "forecast": WF})
                        else:
                            result.append({"time": TM_EF, "temperature": TA, "강수확률": ST,"forecast": WF})
                    except (ValueError, IndexError):
                        continue
            return result
    except Exception as e:
        return []

# 라우트
@app.route('/api/get_weather', methods=['GET'])
def api_get_weather():
    file_name, _ = get_today_weather()
    if file_name:
        date, temperature = extract_temperature(file_name)
        if temperature is not None:
            return jsonify({"date": date, "temperature": temperature})
    return jsonify({"error": "Failed to get weather data"}), 500

@app.route('/api/get_forecast', methods=['GET'])
def api_get_forecast():
    file_name, _ = get_forecast_weather()
    if file_name:
        forecast_data = extract_forecast_data_with_period(file_name)
        if forecast_data:
            return jsonify({"forecast": forecast_data})
    return jsonify({"error": "Failed to get forecast data"}), 500

@app.route('/api/get_avg_temperature', methods=['GET'])
def api_get_avg_temperature():
    try:
        # URL 파라미터에서 날짜 가져오기
        date_str = request.args.get('date')  # URL에서 ?date=YYYYMMDD 형식으로 전달
        if not date_str:
            return jsonify({"error": "Date parameter is required. Format: YYYYMMDD"}), 400

        # 평균 기온 계산
        avg_temp_result = calculate_daily_avg_temperature(date_str)
        if "error" in avg_temp_result:
            return jsonify(avg_temp_result), 500

        return jsonify(avg_temp_result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# 서버 실행
if __name__ == '__main__':
    app.run(debug=True)
